LaughBit 

fun and Joke in terminal. 
